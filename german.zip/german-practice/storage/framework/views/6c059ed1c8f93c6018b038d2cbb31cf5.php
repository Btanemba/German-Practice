



<?php /**PATH C:\Users\anemb\Desktop\german-practice\vendor/backpack/theme-tabler/resources/views/inc/topbar_right_content.blade.php ENDPATH**/ ?>