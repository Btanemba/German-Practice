<!DOCTYPE html>
<html lang="en">
<head>
<title>Sprachraum</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="description" content="Sprachraum">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

<!-- Favicon -->
<link rel="icon" type="image/x-icon" href="<?php echo e(asset('images/logo2.jpg')); ?>">
<link rel="shortcut icon" href="<?php echo e(asset('images/logo2.jpg')); ?>">
<link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('images/logo2.jpg')); ?>">
<link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('images/logo2.jpg')); ?>">
<link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('images/logo2.jpg')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('styles/bootstrap4/bootstrap.min.css')); ?>">
<link href="<?php echo e(asset('plugins/font-awesome-4.7.0/css/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('plugins/OwlCarousel2-2.2.1/owl.carousel.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('plugins/OwlCarousel2-2.2.1/owl.theme.default.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('plugins/OwlCarousel2-2.2.1/animate.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('styles/main_styles.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('styles/responsive.css')); ?>">
<link href="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.15/index.global.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.15/index.global.min.js"></script>
<link href="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.8/main.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.8/main.min.js"></script>

</head>

<?php /**PATH C:\Users\anemb\Desktop\german-practice\resources\views/layouts/nav.blade.php ENDPATH**/ ?>