<?php $__env->startSection('header'); ?>
    <section class="container-fluid d-print-none">
        <h2>
            Send Email to <?php echo e($registration->first_name); ?> <?php echo e($registration->last_name); ?>

        </h2>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-8 offset-md-2">
        <div class="card">
            <div class="card-header">
                <h5>📧 Send Individual Email</h5>
                <p class="text-muted mb-0">To: <?php echo e($registration->email); ?></p>
            </div>
            <div class="card-body">
                <form method="POST" action="<?php echo e(url($crud->route.'/'.$registration->id.'/process-email')); ?>">
                    <?php echo csrf_field(); ?>

                    <div class="form-group mb-3">
                        <label for="subject">Subject</label>
                        <input type="text"
                               class="form-control <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               id="subject"
                               name="subject"
                               value="<?php echo e(old('subject')); ?>"
                               required>
                        <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group mb-3">
                        <label for="message">Message</label>
                        <textarea class="form-control <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                  id="message"
                                  name="message"
                                  rows="8"
                                  required><?php echo e(old('message', "Hello {$registration->first_name},")); ?></textarea>
                        <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group mb-3">
                        <h6>📋 Client Information:</h6>
                        <ul class="list-unstyled">
                            <li><strong>Name:</strong> <?php echo e($registration->first_name); ?> <?php echo e($registration->last_name); ?></li>
                            <li><strong>Email:</strong> <?php echo e($registration->email); ?></li>
                            <li><strong>Type:</strong> <?php echo e($registration->type); ?></li>
                            <?php if($registration->classSchedule): ?>
                                <li><strong>Class:</strong> <?php echo e($registration->classSchedule->level); ?> on <?php echo e($registration->classSchedule->date); ?></li>
                            <?php endif; ?>
                            <?php if($registration->hangout): ?>
                                <li><strong>Hangout:</strong> <?php echo e(\Carbon\Carbon::parse($registration->hangout->date)->format('M d, Y')); ?></li>
                            <?php endif; ?>
                        </ul>
                    </div>

                    <div class="form-group">
                        <button type="submit" class="btn btn-success">
                            <i class="la la-paper-plane"></i> Send Email
                        </button>
                        <a href="<?php echo e(url($crud->route)); ?>" class="btn btn-secondary">
                            <i class="la la-arrow-left"></i> Cancel
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make(backpack_view('blank'), array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\anemb\Desktop\german-practice\resources\views/admin/send_email.blade.php ENDPATH**/ ?>