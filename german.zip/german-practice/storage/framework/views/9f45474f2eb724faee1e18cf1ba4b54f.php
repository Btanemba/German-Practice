<a href="<?php echo e(url($crud->route.'/'.$entry->getKey().'/send-email')); ?>"
   class="btn btn-sm btn-outline-primary"
   title="Send Email">
    <i class="la la-envelope"></i> Email
</a>
<?php /**PATH C:\Users\anemb\Desktop\german-practice\resources\views/vendor/backpack/crud/buttons/send_email_button.blade.php ENDPATH**/ ?>