<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Send Newsletter</h2>

    <form method="POST" action="<?php echo e(route('admin.newsletter.send')); ?>">
        <?php echo csrf_field(); ?>
        <div class="form-group mt-3">
            <label>Subject</label>
            <input type="text" name="subject" class="form-control" placeholder="Newsletter subject" required>
        </div>

        <div class="form-group mt-3">
            <label>Message</label>
            <textarea name="message" class="form-control" rows="6" placeholder="Write your newsletter here..." required></textarea>
        </div>

        <button type="submit" class="btn btn-primary mt-3">Send Newsletter</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make(backpack_view('blank'), array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\anemb\Desktop\german-practice\resources\views/admin/newsletter_form.blade.php ENDPATH**/ ?>