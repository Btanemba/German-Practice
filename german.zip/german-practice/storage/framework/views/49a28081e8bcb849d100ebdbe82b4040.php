
<a href="<?php echo e(route('admin.newsletter.form')); ?>"
   class="btn btn-success"
   title="Send Newsletter to Subscribers">
   <i class="la la-paper-plane"></i> Send Newsletter
</a>
<?php /**PATH C:\Users\anemb\Desktop\german-practice\resources\views/vendor/backpack/crud/buttons/send_newsletter.blade.php ENDPATH**/ ?>