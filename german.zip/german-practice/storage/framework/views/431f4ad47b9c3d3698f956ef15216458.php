
<li class="nav-item">
    <a class="nav-link nav-dashboard" href="<?php echo e(backpack_url('dashboard')); ?>">
        <i class="la la-tachometer-alt nav-icon"></i>
        <span><?php echo e(trans('backpack::base.dashboard')); ?></span>
    </a>
</li>


<li class="nav-item">
    <a class="nav-link nav-events" href="<?php echo e(backpack_url('event')); ?>">
        <i class="la la-calendar-check nav-icon"></i>
        <span>📅 Events</span>
    </a>
</li>


<li class="nav-item">
    <a class="nav-link nav-subscribers" href="<?php echo e(backpack_url('subscriber')); ?>">
        <i class="la la-envelope nav-icon"></i>
        <span>📧 Subscribers</span>
    </a>
</li>


<li class="nav-item">
    <a class="nav-link nav-clients" href="<?php echo e(backpack_url('registration')); ?>">
        <i class="la la-user-friends nav-icon"></i>
        <span>👥 Clients</span>
    </a>
</li>


<li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle nav-activities" href="#" id="activitiesDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
        <i class="la la-rocket nav-icon"></i>
        <span>🎯 Activities</span>
    </a>
    <ul class="dropdown-menu" aria-labelledby="activitiesDropdown">
        <li>
            <a class="dropdown-item" href="<?php echo e(backpack_url('practice-material')); ?>">
                <i class="la la-book-open nav-icon"></i>
                📚 Practice Materials
            </a>
        </li>
        <li>
            <a class="dropdown-item" href="<?php echo e(backpack_url('class-schedule')); ?>">
                <i class="la la-chalkboard-teacher nav-icon"></i>
                🎓 Class Schedules
            </a>
        </li>
    </ul>
</li>

<style>
    /* Modern sidebar styling */
    .sidebar .nav-item .nav-link {
        border-radius: 12px;
        margin: 2px 8px;
        padding: 12px 16px;
        transition: all 0.3s ease;
        position: relative;
        overflow: hidden;
    }

    .sidebar .nav-item .nav-link:hover {
        transform: translateX(5px);
        box-shadow: 0 4px 15px rgba(0,0,0,0.1);
    }

    /* Dashboard - Purple gradient */
    .nav-dashboard:hover {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white !important;
    }

    /* Events - Orange gradient */
    .nav-events:hover {
        background: linear-gradient(135deg, #ff9a9e 0%, #fecfef 100%);
        color: white !important;
    }

    /* Subscribers - Blue gradient */
    .nav-subscribers:hover {
        background: linear-gradient(135deg, #a8edea 0%, #fed6e3 100%);
        color: #333 !important;
    }

    /* Clients - Green gradient */
    .nav-clients:hover {
        background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);
        color: white !important;
    }

    /* Activities dropdown - Pink gradient */
    .nav-activities:hover {
        background: linear-gradient(135deg, #fa709a 0%, #fee140 100%);
        color: white !important;
    }

    /* Dropdown items */
    .sidebar .dropdown-menu {
        border-radius: 12px;
        border: none;
        box-shadow: 0 10px 30px rgba(0,0,0,0.15);
        margin-left: 10px;
    }

    .sidebar .dropdown-item {
        border-radius: 8px;
        margin: 2px 8px;
        padding: 8px 12px;
        transition: all 0.3s ease;
    }

    .sidebar .dropdown-item:hover {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        transform: translateX(3px);
    }

    /* Icons styling */
    .nav-icon {
        width: 20px;
        text-align: center;
        margin-right: 10px;
        font-size: 18px;
    }

    /* Add subtle animation */
    @keyframes slideIn {
        from { opacity: 0; transform: translateX(-10px); }
        to { opacity: 1; transform: translateX(0); }
    }

    .sidebar .nav-item {
        animation: slideIn 0.3s ease;
    }
</style>

<script>
    // Add staggered animation delay for menu items
    document.addEventListener('DOMContentLoaded', function() {
        const menuItems = document.querySelectorAll('.sidebar .nav-item');
        menuItems.forEach((item, index) => {
            item.style.animationDelay = `${index * 0.1}s`;
        });
    });
</script>

<?php /**PATH C:\Users\anemb\Desktop\german-practice\resources\views/vendor/backpack/ui/inc/menu_items.blade.php ENDPATH**/ ?>